import React, { useState } from 'react';
import { StyleSheet, View, TextInput, Button, Modal } from 'react-native';

const ActivityInput = props => {
    const [enteredActivity, setEnteredActivity] = useState('');

    const activityInputHandler = (enteredText) => {
        setEnteredActivity(enteredText);
    }
    //onPress={props.onAddActivity.bind(this, enteredActivity)}

    const addActivityHandler = () => {
        props.onAddActivity(enteredActivity);
        setEnteredActivity('');
    }

    return (
        <Modal visible={props.visible} animationType='slide'>
            <View style={styles.inputContainer}>
                <TextInput
                    placeholder="Actividad"
                    style={styles.input}
                    onChangeText={activityInputHandler}
                    value={enteredActivity}
                />
                <View style={styles.buttonContainer}>
                    <View style={styles.button}>
                        <Button
                            title="Cancelar"
                            color="red"
                            onPress={props.onCancel}
                        />
                    </View>
                    <View style={styles.button}>
                        <Button
                            title="Agregar"
                            onPress={addActivityHandler}
                        />
                    </View>
                </View>

            </View>
        </Modal>
    );
};

const styles = StyleSheet.create({
    input: {
        width: '70%',
        borderColor: 'black',
        borderWidth: 1,
        padding: 10,
        marginBottom: 20
    },
    inputContainer: {
        //flexDirection: 'row',
        flex: 1,
        //justifyContent: 'space-between',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonContainer: {
        flexDirection: 'row',
        width: '80%',
        justifyContent: 'space-between'
    },
    button: {
        width: '50%'
    }
});

export default ActivityInput;